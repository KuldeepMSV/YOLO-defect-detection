# defect detection > 2025-09-18 4:43pm
https://universe.roboflow.com/btp1-dklko/defect-detection-uenxc

Provided by a Roboflow user
License: CC BY 4.0

