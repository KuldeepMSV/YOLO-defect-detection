# defect detection > 2025-09-22 1:46pm
https://universe.roboflow.com/btp1-dklko/defect-detection-uenxc

Provided by a Roboflow user
License: CC BY 4.0

